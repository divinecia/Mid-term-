package org.students.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
public class StudentCourse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long Id;
    @ManyToOne
    @JoinColumn(name = "course_code")
    private Course course;

    @ManyToOne
    @JoinColumn(name = "registration_number")
    private StudentRegistration studentRegistration;

    private int marksInCourse;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public StudentRegistration getStudentRegistration() {
        return studentRegistration;
    }

    public void setStudentRegistration(StudentRegistration studentRegistration) {
        this.studentRegistration = studentRegistration;
    }

    public int getMarksInCourse() {
        return marksInCourse;
    }

    public void setMarksInCourse(int marksInCourse) {
        this.marksInCourse = marksInCourse;
    }
}
