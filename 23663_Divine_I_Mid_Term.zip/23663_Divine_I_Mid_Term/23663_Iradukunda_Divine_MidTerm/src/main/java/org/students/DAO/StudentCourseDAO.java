package org.students.DAO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.students.entity.StudentCourse;
import org.students.util.HibernateUtil;

public class StudentCourseDAO {


    public StudentCourse saveStudentCourseMarks(StudentCourse studentCourse) {
        Transaction transaction = null;
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();

            // Save the student course marks
            session.save(studentCourse);

            transaction.commit();
            return studentCourse;
        } catch (RuntimeException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw e;
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    public int getTotalMarksForSemester(Long registrationNumber) {
        int totalMarks = 0;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query query = session.createQuery("SELECT SUM(sc.marksInCourse) FROM StudentCourse sc WHERE sc.studentRegistration.id = :regId", Long.class);
            query.setParameter("regId", registrationNumber);
            totalMarks = ((Long) query.getSingleResult()).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalMarks;
    }
    public double convertToScaleOfTwenty(Long registrationId) {
        int totalMarks = getTotalMarksForSemester(registrationId);
        return totalMarks / 5.0;  //  graded out of 20 and there are 5 courses
    }
    public String categorizePerformance(Long registrationId) {
        double scaledMarks = convertToScaleOfTwenty(registrationId);
        if (scaledMarks >= 16) {
            return "High Distinction";
        } else if (scaledMarks >= 12) {
            return "Lower Distinction";
        } else if (scaledMarks >= 10) {
            return "Pass";
        } else {
            return "Expel";
        }
    }



}
