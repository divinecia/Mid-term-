package org.students.DAO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.students.entity.Department;
import org.students.entity.Semester;
import org.students.entity.Student;
import org.students.entity.StudentRegistration;
import org.students.util.HibernateUtil;

import javax.management.Query;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class StudentDAO {

    public void saveStudent(Student student) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(student);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public Student getByFirstNameAndLastName(String firstName, String lastName) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Student S WHERE S.firstName = :firstName AND S.lastName = :lastName", Student.class)
                    .setParameter("firstName", firstName)
                    .setParameter("lastName", lastName)
                    .uniqueResult();
        }
    }
    // In StudentDAO.java
    public Long registerStudentToSemesterAndDepartment(Long studentId, Long semesterId, Long departmentId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Student student = session.get(Student.class, studentId);
            Semester semester = session.get(Semester.class, semesterId);
            Department department = session.get(Department.class, departmentId);

            if (student == null || semester == null || department == null) {
                throw new IllegalStateException("Student, Semester, or Department not found!");
            }

            StudentRegistration registration = new StudentRegistration();
            registration.setStudent(student);
            registration.setSemester(semester);
            registration.setDepartment(department);
            registration.setRegistrationDate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
            registration.setRegistrationNumber(generateRegistrationNumber()); // This needs to be a method that generates a number

            session.save(registration);
            transaction.commit();

            return registration.getId();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return null;
        }
    }

    private int generateRegistrationNumber() {
        return (int) (System.currentTimeMillis() % Integer.MAX_VALUE);
    }

}