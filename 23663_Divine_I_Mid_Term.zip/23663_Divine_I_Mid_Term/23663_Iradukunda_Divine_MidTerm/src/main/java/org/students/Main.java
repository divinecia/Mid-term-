package org.students;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hola AUCA!");
    }
}