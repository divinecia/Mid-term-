package org.students.DAO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.students.entity.Course;
import org.students.entity.Semester;
import org.students.util.HibernateUtil;

public class CourseDAO {

    public void saveCourse(Course course, Long semesterId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            Semester semester = session.get(Semester.class, semesterId);
            course.setSemester(semester);

            session.save(course);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
