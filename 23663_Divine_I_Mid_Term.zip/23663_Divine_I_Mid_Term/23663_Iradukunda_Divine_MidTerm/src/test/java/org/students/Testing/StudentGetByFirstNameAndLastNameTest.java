package org.students.Testing;

import org.junit.Before;
import org.junit.Test;
import org.students.DAO.StudentDAO;
import org.students.entity.Student;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class StudentGetByFirstNameAndLastNameTest {
    private StudentDAO studentDAO;

    @Before
    public void setUp() {
        studentDAO = new StudentDAO();
    }

    @Test
    public void testGetByFirstNameAndLastName() {
        Student retrievedStudent = studentDAO.getByFirstNameAndLastName("cia", "ira");
        assertNotNull(retrievedStudent);
        assertEquals("cia", retrievedStudent.getFirstName());
        assertEquals("ia", retrievedStudent.getLastName());
    }
}
