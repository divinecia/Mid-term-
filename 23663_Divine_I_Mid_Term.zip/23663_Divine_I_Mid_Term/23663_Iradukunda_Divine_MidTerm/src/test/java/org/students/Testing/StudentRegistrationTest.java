package org.students.Testing;

import jakarta.persistence.TypedQuery;
import org.hibernate.Session;
import org.junit.Before;
import org.junit.Test;
import org.students.DAO.StudentDAO;
import org.students.entity.Student;
import org.students.entity.Semester;
import org.students.entity.Department;
import org.students.entity.StudentRegistration;
import org.students.util.HibernateUtil;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class StudentRegistrationTest {

    private StudentDAO studentDAO;

    @Before
    public void setup() {
        studentDAO = new StudentDAO();
    }

    @Test
    public void testRegisterStudentToSemesterAndDepartment() {
        Long studentId = 24287L;
        Long semesterId = 1L;
        Long departmentId = 1L;

        studentDAO.registerStudentToSemesterAndDepartment(studentId, semesterId, departmentId);

        List<StudentRegistration> registrations = findRegistrations(studentId, semesterId, departmentId);
        assertFalse("At least one registration should be created", registrations.isEmpty());
    }


    private List<StudentRegistration> findRegistrations(Long studentId, Long semesterId, Long departmentId) {
        List<StudentRegistration> registrations = new ArrayList<>();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM StudentRegistration SR WHERE SR.student.id = :studentId AND SR.semester.id = :semesterId AND SR.department.id = :departmentId";
            TypedQuery<StudentRegistration> query = session.createQuery(hql, StudentRegistration.class);
            query.setParameter("studentId", studentId);
            query.setParameter("semesterId", semesterId);
            query.setParameter("departmentId", departmentId);
            registrations = query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return registrations;
    }


}
