package org.students.Testing;

import org.junit.Before;
import org.junit.Test;
import org.students.DAO.SemesterDAO;
import org.students.entity.Department;
import org.students.entity.Semester;

import static org.junit.Assert.assertNotNull;

public class SemesterTest {

    private SemesterDAO semesterDAO;

    @Before
    public void setup() {
        semesterDAO = new SemesterDAO();
    }

    @Test
    public void testSaveSemester() {
        Semester semester = new Semester();
        semester.setSemesterName("Summer Semester");
        semester.setStartDate("2024-05-03");
        semester.setEndDate("2024-07-04");

        semesterDAO.saveSemester(semester);

        assertNotNull(semester.getId());
    }
    @Test
    public void testSaveDepartment() {
        Department department = new Department();
        department.setDepartmentCode("DEP1");
        department.setDepartmentName("Software Engineering");

        semesterDAO.saveDepartment(department);

        assertNotNull(department.getId());
    }
}
