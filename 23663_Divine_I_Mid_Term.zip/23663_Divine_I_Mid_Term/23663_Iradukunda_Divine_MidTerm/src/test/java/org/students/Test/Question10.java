package org.students.Test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.students.DAO.StudentCourseDAO;

public class Question10 {
private StudentCourseDAO studentCourseDAO;
    @Before
    public void setUp() {
        studentCourseDAO = new StudentCourseDAO();
    }
//test to convert marks to 20
    @Test
    public void testConvertMarks() {
        Long registrationId = 1L;
        double scaledMarks = studentCourseDAO.convertToScaleOfTwenty(registrationId);
        assertTrue("Scaled marks should be calculated", scaledMarks > 0);
        System.out.println("Scaled marks for registration ID " + registrationId + ": " + scaledMarks);
    }
}