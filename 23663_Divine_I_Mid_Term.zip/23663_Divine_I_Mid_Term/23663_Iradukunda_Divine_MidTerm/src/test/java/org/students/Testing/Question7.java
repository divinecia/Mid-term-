package org.students.Testing;

import org.junit.*;
import org.students.DAO.CourseDAO;
import org.students.entity.Course;

import static org.junit.Assert.*;

public class Question7 {
    private CourseDAO courseDAO;

    @Before
    public void setUp() {
        courseDAO = new CourseDAO();
    }

    @Test
    public void testSaveCourses() {
        Long semesterId = 1L;
        String[] courseNames = {"Multivariable", "Testing", "Python", "C", "Web Tech"};
        for (String courseName : courseNames) {
            Course course = new Course();
            course.setCourseName(courseName);
            course.setCourseCode(courseName.substring(0, 3).toUpperCase());
            courseDAO.saveCourse(course, semesterId);
            assertNotNull("Course ID should not be null after save", course.getId());
        }
    }
}
