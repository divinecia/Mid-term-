package org.students.Test;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.*;
import org.students.DAO.StudentCourseDAO;
import org.students.entity.StudentCourse;
import org.students.util.HibernateUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class Question12 {
    private StudentCourseDAO studentCourseDAO;

    @Before
    public void setUp() {
        studentCourseDAO = new StudentCourseDAO();
    }

    @Test
    public void testCategorizePerformance() {
        Map<String, String> results = categorizePerformanceForRegistration(1L);
        for (Map.Entry<String, String> entry : results.entrySet()) {
            System.out.println("Course Code: " + entry.getKey() + ", Category: " + entry.getValue());
        }
        assertTrue("Results should not be empty", !results.isEmpty());
    }

    public Map<String, String> categorizePerformanceForRegistration(Long registrationId) {
        Map<String, String> results = new HashMap<>();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Fetch all courses for a specific registration ID
            Query<StudentCourse> query = session.createQuery("FROM StudentCourse sc WHERE sc.studentRegistration.id = :regId", StudentCourse.class);
            query.setParameter("regId", registrationId);
            List<StudentCourse> courses = query.list();

            for (StudentCourse sc : courses) {
                double scaledMarks = (sc.getMarksInCourse() / 20.0) * 20;  // Scale to 20 points

                String category;
                if (scaledMarks >= 16) {
                    category = "High Distinction";
                } else if (scaledMarks >= 12 && scaledMarks < 16) {
                    category = "Lower Distinction";
                } else if (scaledMarks >= 10 && scaledMarks < 12) {
                    category = "Pass";
                } else {
                    category = "Expel";
                }

                results.put(sc.getCourse().getCourseCode(), category);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }
}
