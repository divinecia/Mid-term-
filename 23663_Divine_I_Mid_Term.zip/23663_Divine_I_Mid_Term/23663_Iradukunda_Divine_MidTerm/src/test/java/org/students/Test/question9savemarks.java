package org.students.Test;

import org.junit.*;
import org.students.DAO.StudentCourseDAO;
import org.students.entity.*;

import static org.junit.Assert.*;

public class question9savemarks {
    private StudentCourseDAO studentCourseDAO;

    @Before
    public void setUp() {
        studentCourseDAO = new StudentCourseDAO();
    }

    @Test
    public void testSaveMarksForCourses() {
        Long registrationId = 1L; // Assume this is valid
        Long[] courseIds = {12L, 13L, 14L, 15L, 16L}; // Assume these are valid course IDs
        int[] marks = {18, 15, 20, 17, 14};

        for (int i = 0; i < courseIds.length; i++) {
            StudentCourse studentCourse = new StudentCourse();
            studentCourse.setCourse(new Course());
            studentCourse.getCourse().setId(courseIds[i]);
            studentCourse.setStudentRegistration(new StudentRegistration());
            studentCourse.getStudentRegistration().setId(registrationId);
            studentCourse.setMarksInCourse(marks[i]);

            StudentCourse savedStudentCourse = studentCourseDAO.saveStudentCourseMarks(studentCourse);
            assertNotNull("StudentCourse ID should not be null after save", savedStudentCourse.getId());
        }
    }
}
