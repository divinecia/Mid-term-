package org.students.Testing;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.junit.Before;
import org.junit.Test;
import org.students.DAO.StudentCourseDAO;
import org.students.entity.*;
import org.students.util.HibernateUtil;

import static org.junit.Assert.*;

public class StudentCourseTest {

    private StudentCourseDAO studentCourseDAO;

    @Before
    public void setup() {
        studentCourseDAO = new StudentCourseDAO();
        setupTestData();
    }

    private void setupTestData() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            if (session.createQuery("from Student").list().isEmpty()) {
                Student student = new Student();
                session.save(student);
            }

            if (session.createQuery("from Semester").list().isEmpty()) {
                Semester semester = new Semester();
                session.save(semester);
            }

            if (session.createQuery("from Department").list().isEmpty()) {
                Department department = new Department();
                session.save(department);
            }

            if (session.createQuery("from Course").list().isEmpty()) {
                Course course = new Course();
                course.setCourseCode("CS106");
                course.setCourseName("Introduction to C Programming");
                Semester semester = session.get(Semester.class, 1L);
                course.setSemester(semester);
                session.save(course);
            }

            if (session.createQuery("from StudentRegistration").list().isEmpty()) {
                Student student = session.get(Student.class, 23663L);
                Department department = session.get(Department.class, 1L);
                Semester semester = session.get(Semester.class, 1L);

                StudentRegistration registration = new StudentRegistration();
                registration.setStudent(student);
                registration.setDepartment(department);
                registration.setSemester(semester);
                session.save(registration);
            }

            tx.commit();
        }
    }

    @Test
    public void testSaveStudentCourseMarks() {
        StudentCourse studentCourse = new StudentCourse();
        studentCourse.setCourse(findCourseByCode("INSY 121"));
        studentCourse.setStudentRegistration(findStudentRegistrationByStudentId(23663L));
        studentCourse.setMarksInCourse(18);

        StudentCourse savedCourse = studentCourseDAO.saveStudentCourseMarks(studentCourse);
        assertNotNull("StudentCourse ID should not be null after save", savedCourse.getId());
    }

    private Course findCourseByCode(String code) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("from Course where courseCode = :code", Course.class)
                    .setParameter("code", code)
                    .getSingleResult();
        }
    }

    private StudentRegistration findStudentRegistrationByStudentId(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(StudentRegistration.class, id);
        }
    }
    public Integer getTotalMarksForSemester(Long registrationId) {
        Integer totalMarks = 0;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "SELECT SUM(sc.marksInCourse) FROM StudentCourse sc " +
                    "WHERE sc.studentRegistration.id = :regId";
            Query<Integer> query = session.createQuery(hql, Integer.class);
            query.setParameter("regId", registrationId);
            totalMarks = query.uniqueResult();
            totalMarks = totalMarks == null ? 0 : totalMarks;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalMarks;
    }
}
