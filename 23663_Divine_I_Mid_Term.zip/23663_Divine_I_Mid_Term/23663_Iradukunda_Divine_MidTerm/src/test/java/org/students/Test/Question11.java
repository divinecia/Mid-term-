package org.students.Test;

import org.junit.*;
import org.students.DAO.StudentCourseDAO;

import static org.junit.Assert.*;

public class Question11 {
    private StudentCourseDAO studentCourseDAO;

    @Before
    public void setUp() {
        studentCourseDAO = new StudentCourseDAO();
    }
//converting marks to 20
    @Test
    public void testConvertMarks() {
        Long registrationId = 1L;
        double scaledMarks = studentCourseDAO.convertToScaleOfTwenty(registrationId);
        assertTrue("Scaled marks should be calculated", scaledMarks > 0);
        System.out.println("Scaled marks for registration ID " + registrationId + ": " + scaledMarks);
    }
}
