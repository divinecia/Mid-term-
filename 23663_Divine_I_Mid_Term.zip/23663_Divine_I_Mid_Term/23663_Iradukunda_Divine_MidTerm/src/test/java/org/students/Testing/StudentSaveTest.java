package org.students.Testing;
import org.junit.*;
import org.students.DAO.StudentDAO;
import org.students.entity.Student;


public class StudentSaveTest {
    private StudentDAO studentDAO;

    @Before
    public void setUp() {
        studentDAO = new StudentDAO();
    }

    @Test
    public void testSaveStudent() {
        Student student = new Student();
        student.setId(24287);
        student.setFirstName("cia");
        student.setLastName("ira");
        student.setDateOfBirth("2000-01-01");
        student.setGender("F");

        studentDAO.saveStudent(student);

    }
}
